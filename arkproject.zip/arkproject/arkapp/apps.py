from django.apps import AppConfig


class ArkappConfig(AppConfig):
    name = 'arkapp'
